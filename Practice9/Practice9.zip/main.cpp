#include "Game.h"
#include <iostream>
#include <ctime>

int main()
{
    Game game;
    game.play();
    return 0;
}
