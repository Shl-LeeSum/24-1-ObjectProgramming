#ifndef CARDJOKER_H
#define CARDJOKER_H
#include "Card.h"

class CardJoker : public Card
{
public:
    CardJoker( );
    ~CardJoker( );
    void printCard( ) const;
};
#endif CARDJOKER_H
